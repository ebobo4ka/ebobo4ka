

<?php 
 $p = 'Приветствую Вас на моей страничке!';
?>

<?php 
 $name = 'Митя';
 $surname = 'Матвеев';
 $city = 'Че';
 $age = 36;
?>


<?php
include 'main.php';
?>
