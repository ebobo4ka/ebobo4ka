            <nav>
                <ul>
                    <li><a href="#"> About my studies </a></li>
                    <li><a href="#"> My portfolio </a></li>
                    <li><a href="#"> My articles </a></li>
                    <li><a href="#"> Links </a></li>
                    <li><a href="#"> Contacts </a></li>
                </ul>    
            </nav>